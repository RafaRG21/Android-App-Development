package com.example.practicabdruizgudino;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText etNumEp, etNombre, etApellido, etSueldo;
    ControladorBD admin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNumEp = (EditText) findViewById(R.id.txtNumEp);
        etNombre = (EditText) findViewById(R.id.txtNombre);
        etApellido = (EditText) findViewById(R.id.txtApellido);
        etSueldo = (EditText) findViewById(R.id.txtSueldo);

        admin = new ControladorBD(this,"empresapatito.db",null,1);
    }

    public void registrarEmpleado(View view){
        SQLiteDatabase bd = admin.getWritableDatabase();
        String nump = etNumEp.getText().toString();
        String nomp = etNombre.getText().toString();
        String apep = etApellido.getText().toString();
        String suep = etSueldo.getText().toString();

        if(!nump.isEmpty() && !nomp.isEmpty() && !apep.isEmpty() && !suep.isEmpty()){
            ContentValues registro = new ContentValues();

            registro.put("numerop",nump);
            registro.put("nombre",nomp);
            registro.put("apellidos",apep);
            registro.put("sueldo",suep);

            if (bd != null) {
                try {
                    bd.insert("empleado",null,registro);
                }catch (SQLException e){
                    Log.e("Exception","Error"+String.valueOf(e.getMessage()));
                }
                bd.close();
            }

            etNumEp.setText("");
            etNombre.setText("");
            etApellido.setText("");
            etSueldo.setText("");
            etNumEp.requestFocus();

            Toast.makeText(this, "Empleado Registrado", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Debes registrar primero los datos", Toast.LENGTH_SHORT).show();
        }
    }//registrarEmpleado

    public void buscarEmpleado(View view){
       SQLiteDatabase bd = admin.getReadableDatabase();
       String nump = etNumEp.getText().toString();

       if(!nump.isEmpty()){
           Cursor fila = bd.rawQuery("select nombre, apellidos, sueldo from empleado"+"where numemp"+nump,null);
           if(fila.moveToFirst()){
               etNumEp.setText(fila.getString(0));
               etApellido.setText(fila.getString(1));
               etSueldo.setText(fila.getString(2));
           }else{
               Toast.makeText(this, "Número de empleado no existe", Toast.LENGTH_SHORT).show();
               etNumEp.setText("");
               etNumEp.requestFocus();
           }
           bd.close();
       }
    }//buscarEmpleado

    public void actualizarEmpleado(View view){
        SQLiteDatabase bd = admin.getWritableDatabase();
        String nump = etNumEp.getText().toString();
        String nomp = etNombre.getText().toString();
        String apep = etApellido.getText().toString();
        String suep = etSueldo.getText().toString();

        if(!nump.isEmpty() && !nomp.isEmpty() && !apep.isEmpty() && !suep.isEmpty() ){
            ContentValues registro = new ContentValues();

            registro.put("numerop",nump);
            registro.put("nombre",nomp);
            registro.put("apellidos",apep);
            registro.put("sueldo",suep);
            int cantidad = 0;
            cantidad = bd.update("empleado",registro,"numemp="+nump,null);
            bd.close();
            etNumEp.setText("");
            etNombre.setText("");
            etApellido.setText("");
            etSueldo.setText("");
            etNumEp.setText("");
            if(cantidad > 0){
                Toast.makeText(this, "Datos del empleado actualizados", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(this, "El número  de empleado no existe", Toast.LENGTH_SHORT).show();
            }


        }else{
            Toast.makeText(this, "Debes registrar los datos primero", Toast.LENGTH_SHORT).show();
        }
    }//actualizarEmpleado


    public void eliminarEmpleado(View view){
        SQLiteDatabase bd = admin.getWritableDatabase();
        String nump = etNumEp.getText().toString();

        if(!nump.isEmpty()){
            int cantidad = 0;
            cantidad = bd.delete("empleado","numemp ="+nump,null);
            bd.close();

            etNumEp.setText("");
            etNombre.setText("");
            etApellido.setText("");
            etSueldo.setText("");
            etNumEp.setText("");
            if(cantidad > 0){
                Toast.makeText(this, "Datos del empleado eliminados", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(this, "El número  de empleado no existe", Toast.LENGTH_SHORT).show();
            }

        }else{
            Toast.makeText(this, "Debes registrar los datos primero", Toast.LENGTH_SHORT).show();
        }

    }//eliminarEmpleado


    public void listarEmpleados(View view){
        Intent intent = new Intent(this, ListadoActivity.class);
        startActivity(intent);
    }//listarEmpleados
 }//class