package com.example.practicabdruizgudino;

import android.content.Context;
import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;

public class ControladorBD extends SQLiteOpenHelper {


    public ControladorBD(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }//Constructor

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "create table employee (numemp int primary key, nombre text, apellido text, sueldo real)";
        try{
            db.execSQL(sql);
        }catch (SQLException e){
            Log.e("ERROR","ERROR"+ e.getMessage());
        }
    }//onCreate

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


}
