package com.example.practica03ruizgudinojoserafael;

import static com.example.practica03ruizgudinojoserafael.MainActivity.NOTIFICATION_ID;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationManagerCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class FormularioActivity extends AppCompatActivity {
    EditText nom, materia, hora;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);
        //habilitar la flecha hacia atras en la barra de estado
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //Instancia para gestionar la notificación
        NotificationManagerCompat notificationManagerCompat =
                NotificationManagerCompat.from(getApplicationContext());
        //Eliminar la notificación de barra de estado
        notificationManagerCompat.cancel(NOTIFICATION_ID);
        nom = findViewById(R.id.txtNameForm);
        materia = findViewById(R.id.txtMateria);
        hora = findViewById(R.id.txtTimeform);
    }//onCreate
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case android.R.id.home:
                //Instancia de la Activity a donde se regresarà la Activity Actual
                Intent intent = new Intent(FormularioActivity.this,
                        MainActivity.class);
                startActivity(intent);
                finish();
                return (true);
        }//switch
        return super.onOptionsItemSelected(item);
    }
    public void registrarExamen(View view){
        String cita;
        cita = nom.getText().toString() + " para la materia " + materia.getText().toString()+" a las "+hora.getText().toString();
        Toast.makeText(this, "Cita registrada a: " + cita,
                Toast.LENGTH_SHORT).show();
        nom.setText("");
        materia.setText("");
        hora.setText("");
    }//registrarCita
}